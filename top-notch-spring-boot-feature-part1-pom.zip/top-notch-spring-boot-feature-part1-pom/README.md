Top notch spring boot application demo
