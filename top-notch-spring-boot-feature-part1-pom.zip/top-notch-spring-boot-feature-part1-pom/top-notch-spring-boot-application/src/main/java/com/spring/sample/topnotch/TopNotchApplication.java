package com.spring.sample.topnotch;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TopNotchApplication {
    public static void main(String[] args) {
        SpringApplication.run(TopNotchApplication.class, args);
    }
}